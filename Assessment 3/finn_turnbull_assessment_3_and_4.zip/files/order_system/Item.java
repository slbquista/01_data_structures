package order_system;

/**
 * @author 1516392
 */

public class Item {
    String name;
    double price;
    
    public Item(String name, double price){
        this.name = name;
        this.price = price;
    }
}
